MINECRAFT JAVA 26.2–26.3 – RESOURCE-PACK
===================================================

VERSIONEN
---------
pack.mcmeta deklariert die Resource-Pack-Formate 88.0 bis 97.1 (Minecraft 26.2
bis 26.3).